class Program
{
public static void main(String a[])
{
ABC a1=new ABC();
ABC a2=new ABC();
a1.incr();
a1.incr();
a1.incr();
a2.incr();
a1.disp();
a2.disp();


}
}