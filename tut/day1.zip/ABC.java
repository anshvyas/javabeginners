class ABC
{
int i;
void incr()
{
i++;
}
void disp()
{
System.out.println(i);
}
}