import java.awt.*;
import java.awt.event.*;
class MyFrame implements ActionListener
{
Frame f;
TextField t1,t2,t3;
Button b1,b2;
MyFrame()
{
f=new Frame();
t1=new TextField(20);
t2=new TextField(20);
t3=new TextField(20);
b1=new Button("Add");
b2=new Button("-");

f.setLayout(new FlowLayout());
f.add(t1);f.add(t2);f.add(t3);f.add(b1);
f.add(b2);
b1.addActionListener(this);
b2.addActionListener(this);
f.setSize(400,400);
f.setVisible(true);
}
public static void main(String ar[])
{
MyFrame f=new MyFrame();
}
public void actionPerformed(ActionEvent e)
{
if(e.getSource()==b1)
{
int a,b,c;
a=Integer.parseInt(t1.getText());
b=Integer.parseInt(t2.getText());
c=a+b;
t3.setText(""+c);
}
if(e.getSource()==b2)
{
int a,b,c;
a=Integer.parseInt(t1.getText());
b=Integer.parseInt(t2.getText());
c=a-b;
t3.setText(""+c);
}

}





}