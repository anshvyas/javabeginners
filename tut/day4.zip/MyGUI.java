import java.awt.*;
class MyGUI
{
public static void main(String ar[])
{
Frame f=new Frame("My First Frame");
TextArea ta=new TextArea();
ta.setBackground(Color.red);
Color c=new Color(50,138,190);
ta.setForeground(c);
Button b=new Button("Click");
TextField t=new TextField();
f.add(ta);
f.add(b,BorderLayout.NORTH);
f.add(t,BorderLayout.SOUTH);
f.setSize(200,200);
f.setVisible(true);
}
}