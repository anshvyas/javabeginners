import java.awt.*;
import java.awt.event.*;
class MyThread extends Thread
{
MyFrame m;
MyThread(MyFrame m)
{
this.m=m;
}
public void run()
{
m.count();
}


}
class MyFrame extends Thread  implements ActionListener
{
TextField t1,t2,t3;
Button b1;
Frame f;
MyFrame()
{
t1=new TextField();
t2=new TextField();
t3=new TextField();
f=new Frame();
b1=new Button("count");
b1.addActionListener(this);
f.setLayout(new GridLayout(4,1));
f.add(t1);
f.add(b1);
f.add(t2);
f.add(t3);
f.setVisible(true);
f.setSize(300,300);
}

void count()
{
int c=0;
int n=Integer.parseInt(t1.getText());
int i,j;
for(i=2;i<n;i++)
{
for(j=2;j<i;j++)
{
if(i%j==0)
break;
}
if(i==j)
c++;
}
t2.setText(""+c);
}
public static void main(String ar[])
{
MyFrame f=new MyFrame();
}
public void actionPerformed(ActionEvent e)
{
MyThread m1=new MyThread(this);
m1.start();
}

}