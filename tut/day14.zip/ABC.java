class ABC 
{
static void print()
{
for(int i=1;i<=200;i++)
{
System.out.println("print"+i);
}
}
}