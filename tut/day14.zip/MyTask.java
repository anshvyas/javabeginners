class MyTask extends Thread
{
public void run()
{
ABC.print();
}
}