class Program
{
public static void main(String ar[])
{
MyTask t=new MyTask();

t.start();
for(int i=1;i<=200;i++)
{
System.out.println("main"+i);
}
}
}