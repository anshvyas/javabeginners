import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

class Client implements ActionListener
{
Socket s;
Frame f;
Button b;
TextField t;
TextArea ta;
Client()
{
try
{
f=new Frame("Client");
b=new Button("Send");
b.addActionListener(this);
t=new TextField();
ta=new TextArea();
f.add(t,BorderLayout.NORTH);
f.add(ta);
f.add(b,BorderLayout.SOUTH);
f.setVisible(true);
f.setSize(300,300);
s=new Socket("localhost",2000);
while(true)
{
ObjectInputStream ois=new ObjectInputStream(s.getInputStream());
String msg=ois.readObject().toString();

ta.append("friend:-"+msg+"\n");

}

}
catch(Exception e)
{
System.out.println(e.getMessage());
}
}
public static void main(String ar[])
{
Client c=new Client();
}
public void actionPerformed(ActionEvent e)
{
try
{
ObjectOutputStream oos=new ObjectOutputStream(s.getOutputStream());
oos.writeObject(t.getText());
ta.append("Me:-"+t.getText()+"\n");
}
catch(Exception e1)
{
System.out.println(e1.getMessage());
}

}
}