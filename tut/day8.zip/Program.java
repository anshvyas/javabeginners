import java.io.*;
import java.util.*;
class Program
{
public static void main(String ar[])
{
InputStreamReader ir=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(ir);
int f=0;
float sal;
String name;
do
{
try
{
System.out.println("Enter name and sal");
name=br.readLine();
sal=Float.parseFloat(br.readLine());
if(sal<0)
throw new MyException();

System.out.println("Your name is "+name);
System.out.println("Your sal is "+sal);

f=1;
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
}while(f!=1);

}
}