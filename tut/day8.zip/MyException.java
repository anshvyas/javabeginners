class MyException extends Exception
{
String msg;
public MyException()
{
msg="Sal must be > 0";
}
public String getMessage()
{
return msg;
}
}