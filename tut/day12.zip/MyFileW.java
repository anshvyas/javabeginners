import java.io.*;
class MyFileW
{
public static void main(String ar[])
{
try
{
String str;


File f=new File("e:\\myfile.txt");
FileReader fw=new FileReader(f);
BufferedReader pw=new BufferedReader(fw);

str=pw.readLine();
while(str!=null)
{
System.out.println(str);
str=pw.readLine();
}
pw.close();
fw.close();



}
catch(Exception e)
{
System.out.println(e.getMessage());
}
}
}