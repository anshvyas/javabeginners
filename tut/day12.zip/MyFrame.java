import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
class MyFrame extends WindowAdapter
{
Frame f;
Button b1,b2;
final TextArea ta;
MyFrame()
{
f=new Frame("Untitled-Notepad");
f.addWindowListener(this);
ta=new TextArea();
b1=new Button("Open");
b1.addActionListener(
new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
JFileChooser jf=new JFileChooser();
jf.showOpenDialog(f);
File fl=jf.getSelectedFile();
FileReader fr=new FileReader(fl);
BufferedReader br=new BufferedReader(fr);
String str=br.readLine();
while(str!=null)
{
ta.append(str+"\n");
str=br.readLine();
}
br.close();
fr.close();


}
catch(Exception e1)
{

}






}
}
);
b2=new Button("Save");

b2.addActionListener(
new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
try
{
JFileChooser jf=new JFileChooser();
jf.showSaveDialog(f);

File fl=jf.getSelectedFile();
FileWriter fw=new FileWriter(fl);
PrintWriter pw=new PrintWriter(fw);
pw.println(ta.getText());
pw.flush();
pw.close();
fw.close();

}
catch(Exception e1)
{
}

}
}
);

f.add(ta);
Panel p=new Panel();
p.setLayout(new GridLayout(1,2));
p.add(b1);
p.add(b2);
f.add(p,BorderLayout.SOUTH);
f.setSize(300,300);
f.setVisible(true);
}
public static void main(String ar[])
{
new MyFrame();
}
public void windowClosing(WindowEvent e)
{
System.exit(0);

}
}
