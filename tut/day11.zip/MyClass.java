import java.awt.*;
import java.awt.event.*;

class MyClass extends WindowAdapter implements ActionListener
{
Frame f;
Button b1,b2;
MyClass()
{
f=new Frame();
b1=new Button();
b1.setBackground(Color.black);
b2=new Button();
b2.setBackground(Color.black);
b1.setBounds(180,320,100,20);
b2.setBounds(220,300,20,20);
b1.addActionListener(this);
f.setLayout(null);
f.addWindowListener(this);
f.add(b1);
f.add(b2);
f.setVisible(true);
f.setSize(400,400);
}
public static void main(String ar[])
{
new MyClass();
}
public void actionPerformed(ActionEvent e)
{
try
{
int y;
do
{
y=b2.getY()-20;
b2.setBounds(220,y,20,20);
Thread.sleep(10);
}while(y>20);
b2.setBounds(220,300,20,20);


}
catch(Exception e1)
{
}
}
public void windowClosing(WindowEvent e)
{
int a=javax.swing.JOptionPane.showConfirmDialog(f,"Are u sure");
if(a==0)
System.exit(0);
}




}