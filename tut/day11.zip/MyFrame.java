import java.awt.*;
import java.awt.event.*;
class MyFrame
{
Frame f;
Button b;
final Checkbox c;
MyFrame()
{
f=new Frame();
b=new Button("MyButton");
b.addActionListener(
new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
javax.swing.JOptionPane.showMessageDialog(null,"Clicked");
}
}
);
c=new Checkbox("haha");
c.addItemListener(new ItemListener()
{
public void itemStateChanged(ItemEvent e)
{
if(c.getState())
javax.swing.JOptionPane.showMessageDialog(null,"u have checked");
else
javax.swing.JOptionPane.showMessageDialog(null,"u have unchecked");

}
});
f.setLayout(new FlowLayout());
f.add(b);
f.add(c);
f.setSize(400,400);
f.setVisible(true);
}
public static void main(String ar[])
{
MyFrame f=new MyFrame();
}
}