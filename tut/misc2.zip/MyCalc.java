import java.awt.*;
import java.awt.event.*;

class MyCalc implements ActionListener
{
Button b[];
Frame f;
TextField t;
int k;
String op;
float op1;
MyCalc()
{
b=new Button[16];
f=new Frame("Calc");
t=new TextField();
Panel p=new Panel();
p.setLayout(new GridLayout(4,4));

f.add(t,BorderLayout.NORTH);
f.add(p);
int i;
for(i=0;i<10;i++)
{
b[i]=new Button(""+i);
b[i].addActionListener(this);
p.add(b[i]);
}
b[10]=new Button("+");
b[10].addActionListener(this);
b[11]=new Button("-");
b[11].addActionListener(this);
b[12]=new Button("*");
b[12].addActionListener(this);
b[13]=new Button("/");
b[13].addActionListener(this);
b[14]=new Button("=");
b[14].addActionListener(this);
b[15]=new Button("On");
b[15].addActionListener(this);
for(i=10;i<16;i++)
{
p.add(b[i]);
}
f.setSize(400,400);
f.setVisible(true);
}
public static void main(String ar[])
{
MyCalc c1=new MyCalc();
}
public void actionPerformed(ActionEvent e)
{
Button bt=(Button)e.getSource();

if(bt==b[0]||bt==b[1]||bt==b[2]||bt==b[3]||bt==b[4]||bt==b[5]||bt==b[6]||bt==b[7]||bt==b[8]||bt==b[9])
{
if(k==0)
{
t.setText(bt.getLabel());
k=1;
}
else
{
t.setText(t.getText()+bt.getLabel());
}


}

if(bt==b[10]||bt==b[11]||bt==b[12]||bt==b[13])
{
op=bt.getLabel();
op1=Float.parseFloat(t.getText());
k=0;
}

if(bt==b[14])
{
float op2=Float.parseFloat(t.getText());
float r=0;
if(op.equals("+"))
r=op1+op2;
if(op.equals("-"))
r=op1-op2;
if(op.equals("*"))
r=op1*op2;
if(op.equals("/"))
r=op1/op2;
t.setText(""+r);
}




}
}