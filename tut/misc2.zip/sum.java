Class ProgramSum
{
public static void main (string c[])

{
int x,y,z ;
x= IntegerparseInteger (a[0]);
y= IntegerparseInteger (a[1]);

z=x+y ;
System.out.println (:sum of" +x+ "and" +y+ "is" +z );
}
}
