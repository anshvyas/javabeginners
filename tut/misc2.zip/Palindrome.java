class Palindrome
{
public static void main (String ar[])
{
String ch="na";
int k=0;
for(String k:a)
{

if(k.startsWith(ch))
System.out.println(k);
}}}