Class Program
{
Static void show()
{
System.out.println("aabbcc");
}
Void input()
{
System.out.println("abcd");
}
public static void main ( String ar[])
{
show();
Program p = new program () ;
p.input() ;
ABC.disp () ;

ABC a1 = new ABC () ;
a1.print () ;
}
}