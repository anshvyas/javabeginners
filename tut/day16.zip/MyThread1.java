class MyThread1 extends Thread
{
ABC a1;
MyThread1(ABC a1)
{
this.a1=a1;
}
public void run()
{
a1.print();
}
}