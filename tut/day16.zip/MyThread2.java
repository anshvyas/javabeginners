class MyThread2 extends Thread
{
ABC a1;
MyThread2(ABC a1)
{
this.a1=a1;
}
public void run()
{
a1.print();
}
}