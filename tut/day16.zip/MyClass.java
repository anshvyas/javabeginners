import java.io.*;

class MyClass
{
public static void main(String ar[])
{
ABC a1=new ABC();
MyThread1 t1=new MyThread1(a1);
MyThread2 t2=new MyThread2(a1);
t1.setName("First");
t2.setName("Second");
t1.setPriority(9);
t2.setPriority(3);
t1.start();
t2.start();
try
{
InputStreamReader ir=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(ir);
String str=br.readLine();
ABC.k=1;
}
catch(Exception e)
{
System.out.println(e.getMessage());
}

}
}