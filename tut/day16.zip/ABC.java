class ABC
{
static int k;
synchronized void print()
{
try
{
k=0;
for(int i=1;i<=10;i++)
{
Thread t=Thread.currentThread();
System.out.println(t.getName()+" "+i);
Thread.sleep(200);
if(k==1)
wait();
}
notify();
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
}
}