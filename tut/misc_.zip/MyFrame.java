import java.awt.*;
import MyLib.*;

class MyFrame
{
TextBox t1,t2,t3;
MyPanel p;
Frame f;
MyFrame()
{
f=new Frame("MyControls");
p=new MyPanel();
t1=new TextBox();
t2=new TextBox();
t3=new TextBox();
p.add(t1);
p.add(t2);
p.add(t3);
f.add(p);
f.setVisible(true);
f.setSize(400,400);
}
public static void main(String ar[])
{
MyFrame f=new MyFrame();
}
}