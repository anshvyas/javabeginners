package MyLib;
import java.awt.*;
public class MyPanel extends Panel
{
public void paint(Graphics g)
{
g.drawString("Eschool",300,300);
}
}