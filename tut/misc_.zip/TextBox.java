package MyLib;
import java.awt.*;
public class TextBox extends TextField 
{
public TextBox()
{
setBackground(Color.red);
setForeground(Color.blue);
setFont(new Font("Arial",1,18));
}
}