import java.awt.*;
import javax.swing.*;
class MyList
{
public static void main(String ar[])
{
JFrame f=new JFrame();
f.setLayout(new FlowLayout());
JRadioButton r1=new JRadioButton("Male");
JRadioButton r2=new JRadioButton("Female");

ButtonGroup b1=new ButtonGroup();
b1.add(r1);
b1.add(r2);
r1.setSelected(true);

f.add(r1);
f.add(r2);


f.setVisible(true);
f.setSize(400,400);
}
}