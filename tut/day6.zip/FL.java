import java.awt.*;


class GL
{
Frame f;
Label l1,l2,l3;
TextField t1,t2,t3;
Button b1,b2;

GL()
{
f=new Frame("Myframe");
l1=new Label("Enter name");
l2=new Label("Enter Pno");
l3=new Label("Enter Email");
t1=new TextField();
t2=new TextField();
t3=new TextField();
b1=new Button("Save");
b2=new Button("Cancel");
GridLayout gl=new GridLayout(4,2);
f.setLayout(gl);
f.add(l1);
f.add(t1);
f.add(l2);
f.add(t2);
f.add(l3);
f.add(t3);
f.add(b1);
f.add(b2);
f.setSize(300,300);
f.setVisible(true);
}
public static void main(String ar[])
{
GL g=new GL();
}
}