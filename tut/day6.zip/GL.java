import java.awt.*;


class GL
{
Frame f;
Label l1,l2,l3;
TextField t1,t2,t3;
Button b1,b2;

GL()
{
f=new Frame("Myframe");
l1=new Label("Enter name");
l2=new Label("Enter Pno");
l3=new Label("Enter Email");
t1=new TextField();
t2=new TextField();
t3=new TextField();
b1=new Button("Save");
b2=new Button("Cancel");
l1.setBounds(100,100,100,20);
t1.setBounds(250,100,100,20);

Font ft=new Font("Arial Black",3,20);
b1.setFont(ft);

l2.setBounds(100,150,100,20);
t2.setBounds(250,150,100,20);
l3.setBounds(100,200,100,20);
t3.setBounds(250,200,100,20);
b1.setBounds(100,250,70,20);
b2.setBounds(250,250,70,20);

f.setLayout(null);
f.add(l1);
f.add(t1);
f.add(l2);
f.add(t2);
f.add(l3);
f.add(t3);
f.add(b1);
f.add(b2);
f.setSize(300,300);
f.setVisible(true);

}
public static void main(String ar[])
{
GL g=new GL();
}
}