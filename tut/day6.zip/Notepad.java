import java.awt.*;

class Notepad
{
Frame f;
MenuBar mb;
Menu file,edit,format;
MenuItem nw,open,save,cut,copy,paste;
TextArea ta;
Notepad()
{
f=new Frame("Untitled - Notepad");
mb=new MenuBar();
file=new Menu("File");
edit=new Menu("Edit");
format=new Menu("Format");
nw=new MenuItem("New");
open=new MenuItem("Open");
save=new MenuItem("Save");
cut=new MenuItem("Cut");
copy=new MenuItem("Copy");
paste=new MenuItem("Paste");

file.add(nw);
file.add(open);
file.add(new MenuItem("-"));
file.add(save);

edit.add(cut);
edit.add(copy);
edit.add(paste);

mb.add(file);
mb.add(edit);
mb.add(format);

ta=new TextArea();

f.setMenuBar(mb);
f.add(ta);
f.setSize(400,400);
f.setVisible(true);
}
public static void main(String ar[])
{
Notepad n=new Notepad();
}


}