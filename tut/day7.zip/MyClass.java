import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
class MyClass
{
public static void main(String ar[])throws IOException
{
InputStreamReader ir=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(ir);
int k;
System.out.println("Enter size");
k=Integer.parseInt(br.readLine());
int a[]=new int[k];
System.out.println("Enter "+k+" nos");
int i,m;
for(i=0;i<k;i++)
{
a[i]=Integer.parseInt(br.readLine());
}
System.out.println("Enter value to be searched");
m=Integer.parseInt(br.readLine());
for(i=0;i<k;i++)
{
if(a[i]==m)
break;
}

if(k==i)
System.out.println("Element does not exist");
else
System.out.println("Found at"+(i+1));
}
}

