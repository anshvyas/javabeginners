class MyThread2 extends Thread
{
public void run()
{
try
{
for(int i=1;i<=10;i++)
{
System.out.println("Thread"+i);
Thread.sleep(300);
}
}
catch(Exception e)
{

}
}
}