class MyThread1 extends Thread
{
public void run()
{
ABC.print();
}
}