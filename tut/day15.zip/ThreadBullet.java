import java.awt.*;
class ThreadBullet extends Thread
{
public void run()
{
Button b2=new Button();
b2.setBounds(240,400,10,10);
b2.setBackground(Color.black);
Game.f.add(b2);
try
{
for(int i=400;i>=0;i-=5)
{
b2.setBounds(240,i,10,10);
Thread.sleep(10);
}

}
catch(Exception e)
{
}
}
}