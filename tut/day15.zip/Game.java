import java.awt.*;
import java.awt.event.*;

class Game implements ActionListener
{
static Button b1,b2,b3;
static Frame f;
static Label l;
Game()
{
f=new Frame();
b1=new Button("Tank");

b3=new Button();
l=new Label("60");
l.setBounds(350,400,30,20);
f.setLayout(null);

b1.setBounds(220,420,60,20);
b1.setBackground(Color.black);

b3.setBounds(0,30,100,20);
b3.setBackground(Color.black);
b1.addActionListener(this);
f.add(l);
f.add(b1);
f.add(b3);
f.setSize(400,400);

f.setVisible(true);
ThreadTarget t1=new ThreadTarget();
t1.start();
ThreadLabel t2=new ThreadLabel();
t2.start();


}
public static void main(String ar[])
{
Game g=new Game();
}
public void actionPerformed(ActionEvent e)
{

ThreadBullet t1=new ThreadBullet();
t1.start();
MakeSound m=new MakeSound();
m.playSound("error.wav");

}
}