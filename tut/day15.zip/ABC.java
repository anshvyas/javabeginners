class ABC
{
synchronized static void print()
{
try
{
for(int i=1;i<=10;i++)
{
System.out.println(i);
Thread.sleep(300);
}
}
catch(Exception e)
{

}
}
}