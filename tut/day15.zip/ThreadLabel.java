class ThreadLabel extends Thread
{
public void run()
{
try
{
while(Integer.parseInt(Game.l.getText())>0)
{
int a=Integer.parseInt(Game.l.getText());
a--;
Thread.sleep(1000);
Game.l.setText(""+a);
}
}
catch(Exception e)
{
}
}
}