class Program
{
public static void main(String ar[])
{
MyThread2 t2=new MyThread2();
t2.start();
try
{
for(int i=1;i<=10;i++)
{
System.out.println("main"+i);
if(i==5)
t2.join();

Thread.sleep(300);
}
}
catch(Exception e)
{

}
}
}