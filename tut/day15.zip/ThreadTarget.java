class ThreadTarget extends Thread
{
public void run()
{
try
{
while(Integer.parseInt(Game.l.getText())>0)
{
for(int i=0;i<=400;i+=5)
{
Game.b3.setBounds(i,30,100,20);
Thread.sleep(10);
if(Integer.parseInt(Game.l.getText())<=0)
break;
}
}
}
catch(Exception e)
{
}
}
}