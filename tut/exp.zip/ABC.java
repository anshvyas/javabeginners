class ABC
{
public static void main(String ar[])
{
MakeSound m=new MakeSound();
m.playSound(ar[0]);
}
}