import java.awt.*;
import java.awt.event.*;

class My implements MouseMotionListener
{
Frame f;
Label l;
My()
{
f=new Frame();
l=new Label();
f.add(l,BorderLayout.SOUTH);
f.addMouseMotionListener(this);
f.setSize(400,400);
f.setVisible(true);

}
public static void main(String ar[])
{
new My();
}
public void mouseMoved(MouseEvent e)
{
String str=e.getX()+" , "+e.getY();
l.setText(str);
}

public void mouseDragged(MouseEvent e)
{
}
}