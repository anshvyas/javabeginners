class Program
{
public static void main(String a[])
{
int x,y,z;

x=Integer.parseInt(a[0]);
y=Integer.parseInt(a[1]);

z=x+y;
System.out.println("Sum of "+x+" and "+y+" is "+z);



}
}